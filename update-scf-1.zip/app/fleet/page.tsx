import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import SiteHeader from "@/app/components/site-header";
import { getPlanAccess } from "@/lib/plan-access";
import {
  addVessel,
  deleteVessel,
  addPlannedCrew,
  activatePlannedCrew,
  deletePlannedCrew,
  rehireCrew,
  moveToPlannedFromHistory,
} from "@/lib/actions/fleet";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "My Fleet \u2014 ShipCrewFinder",
  noindex: true,
});

export default async function FleetPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const added = sp.added;
  const deleted = sp.deleted;
  const planned = sp.planned;
  const error = sp.error;
  const fVessel = sp.fVessel || "";
  const fRank = sp.fRank || "";
  const costVessel = sp.costVessel || "";
  const healthView = sp.healthView || "";

  const supabase = await createClient();
  const {
    data: { session },
  } = await supabase.auth.getSession();
  const user = session?.user ?? null;
  if (!user) redirect("/login");

  const [{ data: profile }, { count: unreadCount }] = await Promise.all([
    supabase.from("profiles").select("user_type, plan").eq("id", user.id).single(),
    supabase
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("read", false),
  ]);

  if (!profile || profile.user_type !== "company") redirect("/dashboard");

  const myPlan = (profile.plan as string) || "free";
  const access = getPlanAccess(myPlan as never);

  const { data: vessels } = await supabase
    .from("vessels")
    .select("id, name, imo_number, vessel_type, flag, dwt, created_at")
    .eq("company_id", user.id)
    .order("created_at", { ascending: false });

  const vesselList = vessels || [];
  const vesselCount = vesselList.length;
  const atLimit = access.vesselLimit !== null && vesselCount >= access.vesselLimit;
  const vesselIds = vesselList.map((v) => v.id as string);

  const crewCountMap: Record<string, number> = {};
  const vesselNameMap: Record<string, string> = {};
  vesselList.forEach((v) => {
    vesselNameMap[v.id as string] = v.name as string;
  });

  let activeCrew: Record<string, unknown>[] = [];
  let historyCrew: Record<string, unknown>[] = [];
  let plannedCrew: Record<string, unknown>[] = [];

  if (vesselIds.length > 0) {
    const { data: allCrew } = await supabase
      .from("fleet_crew")
      .select("id, full_name, rank, vessel_id, status, join_date, departure_date, notes, expected_join_date, planning_country, planning_status, passport_expiry, visa_expiry, passport_number, seaman_book_number, seaman_book_expiry, health_report_expiry, emergency_contact_name, emergency_contact_phone, nationality")
      .in("vessel_id", vesselIds)
      .order("created_at", { ascending: false });

    const list = allCrew || [];
    activeCrew = list.filter((c) => (c.status as string) === "active");
    historyCrew = list.filter((c) => (c.status as string) === "signed_off").slice(0, 10);
    plannedCrew = list.filter((c) => (c.status as string) === "planned");

    activeCrew.forEach((c) => {
      const vid = c.vessel_id as string;
      crewCountMap[vid] = (crewCountMap[vid] || 0) + 1;
    });
  }

  const fmtDwt = (d: number | null) => (d ? Number(d).toLocaleString("en-US") + " DWT" : null);
  const fmtDate = (d: string | null) =>
    d
      ? new Date(d + "T00:00:00").toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      : "—";

  const getPlanningRisk = (c: Record<string, unknown>): string | null => {
    const expectedJoin = c.expected_join_date as string | null;
    if (!expectedJoin) return null;
    const joinDate = new Date(expectedJoin + "T00:00:00");

    const passportExp = c.passport_expiry as string | null;
    if (passportExp) {
      const pExp = new Date(passportExp + "T00:00:00");
      const daysBuffer = Math.round((pExp.getTime() - joinDate.getTime()) / (24 * 3600 * 1000));
      if (daysBuffer < 0) return "Passport expires before planned join date";
      if (daysBuffer < 180) return "Passport has less than 6 months validity at join";
    }

    const visaExp = c.visa_expiry as string | null;
    if (visaExp) {
      const vExp = new Date(visaExp + "T00:00:00");
      if (vExp.getTime() < joinDate.getTime()) return "Visa expires before planned join date";
    }

    return null;
  };

  const rankSet = new Set<string>();
  historyCrew.forEach((c) => { if (c.rank) rankSet.add(c.rank as string); });
  plannedCrew.forEach((c) => { if (c.rank) rankSet.add(c.rank as string); });
  const rankOptions = Array.from(rankSet).sort();

  const historyCrewFiltered = historyCrew.filter((c) => {
    if (fVessel && (c.vessel_id as string) !== fVessel) return false;
    if (fRank && (c.rank as string) !== fRank) return false;
    return true;
  });
  const plannedCrewFiltered = plannedCrew.filter((c) => {
    if (fVessel && (c.vessel_id as string) !== fVessel) return false;
    if (fRank && (c.rank as string) !== fRank) return false;
    return true;
  });

  let alertPassport = 0;
  let alertHealth = 0;
  let alertVisa = 0;
  let alertStcw = 0;
  if (vesselIds.length > 0) {
    const { data: expiryRows } = await supabase
      .from("fleet_crew")
      .select("passport_expiry, health_report_expiry, visa_expiry, stcw_endorsement_expiry")
      .in("vessel_id", vesselIds)
      .eq("status", "active");

    const today2 = new Date();
    today2.setHours(0, 0, 0, 0);
    const dayMs2 = 24 * 3600 * 1000;
    const isSoonOrExpired = (d: string | null) => {
      if (!d) return false;
      const days = Math.round((new Date(d + "T00:00:00").getTime() - today2.getTime()) / dayMs2);
      return days <= 30;
    };

    (expiryRows || []).forEach((r) => {
      if (isSoonOrExpired(r.passport_expiry as string | null)) alertPassport++;
      if (isSoonOrExpired(r.health_report_expiry as string | null)) alertHealth++;
      if (isSoonOrExpired(r.visa_expiry as string | null)) alertVisa++;
      if (isSoonOrExpired(r.stcw_endorsement_expiry as string | null)) alertStcw++;
    });
  }
  const totalAlerts = alertPassport + alertHealth + alertVisa + alertStcw;

  const today3 = new Date();
  today3.setHours(0, 0, 0, 0);
  const dayMs3 = 24 * 3600 * 1000;
  const expiryStatus3 = (d: string | null): string => {
    if (!d) return "none";
    const days = Math.round((new Date(d + "T00:00:00").getTime() - today3.getTime()) / dayMs3);
    if (days < 0) return "expired";
    return "ok";
  };

  let readySum = 0;
  const crewHealthList: { id: string; name: string; rank: string; vesselId: string; score: number }[] = [];
  activeCrew.forEach((c) => {
    const checks: boolean[] = [];
    checks.push(!!(c.passport_number && expiryStatus3(c.passport_expiry as string | null) !== "expired" && c.passport_expiry));
    checks.push(!!(c.seaman_book_number && expiryStatus3(c.seaman_book_expiry as string | null) !== "expired" && c.seaman_book_expiry));
    checks.push(!!(c.health_report_expiry && expiryStatus3(c.health_report_expiry as string | null) !== "expired"));
    checks.push(!!(c.emergency_contact_name && c.emergency_contact_phone));
    checks.push(!!c.nationality);
    const passed = checks.filter(Boolean).length;
    const score = Math.round((passed / checks.length) * 100);
    readySum += score;
    crewHealthList.push({
      id: c.id as string,
      name: c.full_name as string,
      rank: (c.rank as string) || "Crew",
      vesselId: c.vessel_id as string,
      score,
    });
  });
  const fullyReadyCount = crewHealthList.filter((c) => c.score === 100).length;
  const atRiskCount = crewHealthList.filter((c) => c.score < 50).length;
  const fleetHealthScore = activeCrew.length > 0 ? Math.round(readySum / activeCrew.length) : null;
  const healthCls = fleetHealthScore === null ? "" : fleetHealthScore >= 80 ? "hgood" : fleetHealthScore >= 50 ? "hmid" : "hbad";
  const healthViewList =
    healthView === "ready" ? crewHealthList.filter((c) => c.score === 100)
    : healthView === "atrisk" ? crewHealthList.filter((c) => c.score < 50)
    : [];

  const costByCurrency: Record<string, number> = {};
  if (vesselIds.length > 0) {
    const costVesselIds = costVessel ? [costVessel] : vesselIds;
    const { data: salaryRows } = await supabase
      .from("fleet_crew")
      .select("salary_amount, salary_currency")
      .in("vessel_id", costVesselIds)
      .eq("status", "active");

    (salaryRows || []).forEach((r) => {
      const amt = r.salary_amount as number | null;
      if (!amt) return;
      const cur = (r.salary_currency as string) || "USD";
      costByCurrency[cur] = (costByCurrency[cur] || 0) + amt;
    });
  }
  const costCurrencies = Object.keys(costByCurrency);
  const fmtMoney = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });

  const { data: auditRows } = await supabase
    .from("fleet_audit_log")
    .select("action, detail, actor_email, created_at")
    .eq("company_id", user.id)
    .order("created_at", { ascending: false })
    .limit(6);

  const actionIcon = (a: string) => {
    if (a.includes("added")) return "➕";
    if (a.includes("deleted") || a.includes("removed")) return "🗑️";
    if (a.includes("signed_off")) return "📤";
    if (a.includes("rehired")) return "🔄";
    if (a.includes("activated")) return "📥";
    if (a.includes("updated")) return "✏️";
    return "•";
  };

  const fmtWhen = (d: string) => {
    const diffMs = Date.now() - new Date(d).getTime();
    const mins = Math.floor(diffMs / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return mins + "m ago";
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return hrs + "h ago";
    const days = Math.floor(hrs / 24);
    return days + "d ago";
  };

  return (
    <>
      <style>{`
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:var(--body);background:var(--navy);color:var(--tx);overflow-x:hidden}
  .wrap{max-width:940px;margin:0 auto;padding:0 20px}
  .fl-hero{position:relative;padding:36px 0 20px;overflow:hidden}
  .aur{position:absolute;width:440px;height:440px;top:-230px;right:-120px;border-radius:50%;filter:blur(90px);opacity:.42;background:radial-gradient(circle,rgba(251,191,36,.3),transparent 65%);pointer-events:none}
  .back{display:inline-flex;align-items:center;gap:7px;color:var(--tx3);text-decoration:none;font-size:13px;font-weight:600;transition:.18s;margin-bottom:16px}
  .back:hover{color:var(--gold)}
  h1{font-family:var(--disp);font-size:clamp(1.7rem,4.2vw,2.5rem);font-weight:800;line-height:1.1;letter-spacing:-.02em;margin-bottom:8px}
  .sub{font-size:14px;color:var(--tx2);line-height:1.6}
  section{padding:20px 0 44px}
  .stitle{display:flex;align-items:center;gap:9px;font-size:12.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--gold);margin:28px 0 12px}
  .banner{border-radius:13px;padding:13px 17px;font-size:13px;margin-bottom:16px;border:1px solid;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}
  .banner.ok{color:var(--grn);border-color:rgba(52,211,153,.3);background:rgba(52,211,153,.08)}
  .banner.err{color:#f87171;border-color:rgba(239,68,68,.3);background:rgba(239,68,68,.08)}
  .banner.info{color:var(--gold);border-color:rgba(251,191,36,.3);background:rgba(251,191,36,.08)}
  .alertpanel{display:flex;align-items:flex-start;gap:15px;border:1.5px solid rgba(239,68,68,.32);background:linear-gradient(150deg,rgba(239,68,68,.09),var(--navy2) 45%);border-radius:17px;padding:18px 20px;margin-bottom:18px;box-shadow:0 4px 18px rgba(0,0,0,.2)}
  .alertpanel .ai{width:36px;height:36px;border-radius:10px;background:rgba(239,68,68,.14);border:1px solid rgba(239,68,68,.3);display:grid;place-items:center;font-size:17px;flex-shrink:0}
  .alertpanel b{font-family:var(--disp);font-size:14.5px;display:block;margin-bottom:5px;color:var(--tx);letter-spacing:-.01em}
  .alertpanel p{font-size:12.5px;color:var(--tx2);line-height:1.65}
  .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border-radius:11px;font-weight:700;font-size:12.5px;text-decoration:none;cursor:pointer;transition:.18s;border:none;padding:9px 16px;font-family:var(--body);white-space:nowrap}
  .btn-gold{background:linear-gradient(135deg,var(--gold),var(--gold2));color:#0b0e13}
  .btn-gold:hover{transform:translateY(-2px)}
  .card{background:linear-gradient(165deg,var(--navy2),var(--ink));border:1px solid var(--line2);border-radius:18px;padding:22px 24px;margin-bottom:20px;box-shadow:0 4px 16px rgba(0,0,0,.18)}
  .card h2{font-family:var(--disp);font-size:16px;font-weight:800;margin-bottom:14px;letter-spacing:-.01em}
  .frow{display:grid;grid-template-columns:1.6fr 1fr 1fr 1fr 1fr auto;gap:10px;align-items:end}
  @media(max-width:900px){.frow{grid-template-columns:1fr 1fr}}
  label{display:block;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tx3);margin-bottom:6px}
  input[type=text],input[type=number],input[type=date],select{width:100%;background:var(--navy);border:1px solid var(--line2);color:var(--tx);border-radius:11px;padding:11px 13px;font-family:var(--body);font-size:13.5px;outline:none}
  input:focus,select:focus{border-color:var(--gold)}
  input:disabled{opacity:.5;cursor:not-allowed}
  select{cursor:pointer;appearance:none;background-image:url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath fill='%23fbbf24' d='M6 8L0 0h12z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 0.85rem center;padding-right:2.2rem}
  .btn-add{display:inline-flex;align-items:center;justify-content:center;gap:8px;border-radius:11px;font-weight:700;font-size:13.5px;cursor:pointer;transition:.18s;border:none;padding:11px 19px;font-family:var(--body)}
  .btn-add.on{background:linear-gradient(135deg,var(--gold),var(--gold2));color:#0b0e13}
  .btn-add.on:hover{transform:translateY(-2px)}
  .vgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:16px;margin-bottom:28px}
  .vcard{background:linear-gradient(165deg,var(--navy2),var(--ink));border:1px solid var(--line2);border-radius:18px;padding:22px;text-decoration:none;color:var(--tx);transition:.25s cubic-bezier(.2,.8,.2,1);display:block;position:relative;overflow:hidden;box-shadow:0 4px 18px rgba(0,0,0,.25)}
  .vcard::before{content:"";position:absolute;inset:0;background:radial-gradient(circle at top right,rgba(251,191,36,.08),transparent 60%);opacity:0;transition:.25s}
  .vcard:hover{transform:translateY(-5px);border-color:rgba(251,191,36,.55);box-shadow:0 14px 32px rgba(0,0,0,.4),0 0 0 1px rgba(251,191,36,.12)}
  .vcard:hover::before{opacity:1}
  .vcard .vi{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,rgba(251,191,36,.18),rgba(251,191,36,.05));border:1px solid rgba(251,191,36,.25);display:grid;place-items:center;font-size:20px;margin-bottom:14px}
  .vcard b{font-family:var(--disp);font-size:17px;display:block;margin-bottom:5px;letter-spacing:-.01em}
  .vcard p{font-size:12px;color:var(--tx3);line-height:1.65}
  .vdel{position:absolute;top:14px;right:14px}
  .vdel button{background:none;border:1px solid var(--line2);color:var(--tx3);border-radius:8px;padding:5px 9px;font-size:11px;font-weight:700;cursor:pointer;font-family:var(--body)}
  .vdel button:hover{color:#f87171;border-color:rgba(239,68,68,.4)}
  .empty{text-align:center;padding:30px 12px;font-size:13.5px;color:var(--tx2);line-height:1.7}
  .plist{display:flex;flex-direction:column;gap:9px}
  .prow{display:flex;align-items:center;gap:12px;border:1px solid var(--line2);border-radius:13px;padding:12px 14px;background:rgba(255,255,255,.02);flex-wrap:wrap}
  .pavatar{flex-shrink:0;width:38px;height:38px;border-radius:11px;background:rgba(251,191,36,.13);border:1px solid rgba(251,191,36,.3);display:grid;place-items:center;font-family:var(--disp);font-weight:800;font-size:13px;color:var(--gold)}
  .pinfo{flex:1;min-width:160px}
  .pname{font-family:var(--disp);font-weight:700;font-size:13.5px}
  .pmeta{font-size:11.5px;color:var(--tx3);margin-top:2px}
  .ppill{font-size:10px;font-weight:800;border-radius:999px;padding:4px 10px;border:1px solid;white-space:nowrap}
  .ppill.confirmed{color:var(--grn);border-color:rgba(52,211,153,.35);background:rgba(52,211,153,.08)}
  .ppill.tentative{color:var(--gold);border-color:rgba(251,191,36,.35);background:rgba(251,191,36,.08)}
  .ppill.docs{color:#f87171;border-color:rgba(239,68,68,.35);background:rgba(239,68,68,.08)}
  .pacts{display:flex;gap:6px;flex-shrink:0}
  .pacts button{background:none;border:1px solid var(--line2);color:var(--tx3);border-radius:8px;padding:6px 11px;font-size:11px;font-weight:700;cursor:pointer;font-family:var(--body)}
  .pacts button.go{color:var(--grn);border-color:rgba(52,211,153,.4)}
  .pacts button.go:hover{background:rgba(52,211,153,.1)}
  .pacts button.x:hover{color:#f87171;border-color:rgba(239,68,68,.4)}
  .ptarget{font-family:var(--disp);font-weight:800;font-size:13px;color:var(--gold);margin-top:2px}
  .rehireform{display:flex;gap:7px;align-items:center;flex-shrink:0}
  .rehiresel{background:var(--navy);border:1px solid var(--line2);color:var(--tx);border-radius:8px;padding:6px 9px;font-size:11.5px;font-family:var(--body);cursor:pointer;max-width:130px}
  .rehiresel:focus{border-color:var(--gold)}
  .histacts{display:flex;flex-direction:column;gap:6px;flex-shrink:0}
  .planbtn{background:rgba(96,165,250,.1);border:1px solid rgba(96,165,250,.4);color:#60a5fa;border-radius:8px;padding:6px 11px;font-size:11px;font-weight:700;cursor:pointer;font-family:var(--body)}
  .planbtn:hover{background:rgba(96,165,250,.18)}
  .alist{display:flex;flex-direction:column;gap:2px}
  .arow{display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px solid var(--line2);font-size:12.5px}
  .arow:last-child{border-bottom:none}
  .aic{flex-shrink:0;font-size:13px}
  .atext{flex:1;color:var(--tx2)}
  .awhen{flex-shrink:0;color:var(--tx3);font-size:11px;white-space:nowrap}
  .filterbar{display:flex;gap:10px;align-items:center;margin-bottom:6px;flex-wrap:wrap}
  .filtersel{background:var(--navy);border:1px solid var(--line2);color:var(--tx);border-radius:10px;padding:9px 13px;font-size:12.5px;font-family:var(--body);cursor:pointer;min-width:140px}
  .filtersel:focus{border-color:var(--gold)}
  .costcard{background:linear-gradient(150deg,rgba(52,211,153,.07),var(--navy2) 40%,var(--ink));border:1px solid rgba(52,211,153,.28);border-radius:17px;padding:18px 22px;margin-bottom:18px;box-shadow:0 4px 18px rgba(0,0,0,.2)}
  .costhead{display:flex;align-items:center;gap:10px;margin-bottom:14px}
  .costhead span{width:32px;height:32px;border-radius:10px;background:rgba(52,211,153,.14);border:1px solid rgba(52,211,153,.3);display:grid;place-items:center;font-size:15px;flex-shrink:0}
  .costhead b{font-family:var(--disp);font-size:13.5px;color:var(--tx);letter-spacing:-.01em}
  .costrows{display:flex;flex-direction:column;gap:8px}
  .costrow{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
  .costcur{font-size:11px;font-weight:800;color:var(--tx3);letter-spacing:.05em;min-width:32px}
  .costval{font-family:var(--disp);font-size:19px;font-weight:800;color:var(--grn)}
  .costproj{font-size:11.5px;color:var(--tx3)}
  .costsel{background:var(--navy);border:1px solid var(--line2);color:var(--tx);border-radius:9px;padding:6px 11px;font-size:12px;font-family:var(--body);cursor:pointer}
  .costsel:focus{border-color:var(--gold);outline:none}
  .costgo{background:var(--gold);color:#0b0e13;border:none;border-radius:9px;padding:6px 13px;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--body)}
  .costgo:hover{background:var(--gold2)}
  .filehint{font-size:11px;color:var(--tx3)}
  .riskwarn{font-size:11px;font-weight:700;color:var(--red);margin-top:4px}
  .healthcard{display:flex;align-items:center;gap:16px;border-radius:17px;padding:16px 20px;margin-bottom:18px;box-shadow:0 4px 18px rgba(0,0,0,.2);border:1px solid var(--line2);background:linear-gradient(150deg,rgba(255,255,255,.03),var(--navy2) 40%)}
  .healthcard.hgood{border-color:rgba(52,211,153,.32);background:linear-gradient(150deg,rgba(52,211,153,.09),var(--navy2) 45%)}
  .healthcard.hmid{border-color:rgba(251,191,36,.32);background:linear-gradient(150deg,rgba(251,191,36,.09),var(--navy2) 45%)}
  .healthcard.hbad{border-color:rgba(239,68,68,.32);background:linear-gradient(150deg,rgba(239,68,68,.09),var(--navy2) 45%)}
  .healthring{width:58px;height:58px;border-radius:50%;flex-shrink:0;display:grid;place-items:center;font-family:var(--disp);font-weight:800;font-size:15px;border:3px solid}
  .healthcard.hgood .healthring{border-color:var(--grn);color:var(--grn)}
  .healthcard.hmid .healthring{border-color:var(--gold);color:var(--gold)}
  .healthcard.hbad .healthring{border-color:var(--red);color:var(--red)}
  .healthcard b{font-family:var(--disp);font-size:14.5px;display:block;margin-bottom:4px;color:var(--tx);letter-spacing:-.01em}
  .healthcard p{font-size:12.5px;color:var(--tx2)}
  .healthlink{color:inherit;text-decoration:underline;text-underline-offset:2px;font-weight:700}
  .healthlink.hlgood{color:var(--grn)}
  .healthlink.hlbad{color:var(--red)}
  .healthlink:hover{opacity:.8}
  .rdybadge{display:inline-block;font-size:11px;font-weight:800;border-radius:999px;padding:3px 10px;border:1px solid}
  .rdybadge.rdy-high{color:var(--grn);border-color:rgba(52,211,153,.4);background:rgba(52,211,153,.1)}
  .rdybadge.rdy-mid{color:var(--gold);border-color:rgba(251,191,36,.4);background:rgba(251,191,36,.1)}
  .rdybadge.rdy-low{color:var(--red);border-color:rgba(239,68,68,.4);background:rgba(239,68,68,.1)}
  .ttwrap{overflow-x:auto;-webkit-overflow-scrolling:touch;border-radius:14px;border:1px solid var(--line2)}
  table.ctable{width:100%;border-collapse:collapse;min-width:640px;font-size:12.5px}
  table.ctable thead th{text-align:left;font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--tx3);padding:11px 12px;background:rgba(255,255,255,.03);border-bottom:1px solid var(--line2);white-space:nowrap}
  table.ctable tbody td{padding:11px 12px;border-bottom:1px solid var(--line2);white-space:nowrap;color:var(--tx2)}
  table.ctable tbody tr:last-child td{border-bottom:none}
  table.ctable tbody tr:hover{background:rgba(251,191,36,.04)}
  table.ctable .tname{color:var(--tx);font-weight:700;text-decoration:none;font-family:var(--disp)}
  table.ctable .tname:hover{color:var(--gold)}
  table.ctable .tdel{background:none;border:1px solid var(--line2);color:var(--tx3);border-radius:7px;padding:4px 9px;font-size:11px;font-weight:700;cursor:pointer;font-family:var(--body)}
  table.ctable .tdel:hover{color:var(--red);border-color:rgba(239,68,68,.4)}
  .tnoteflag{margin-left:6px;font-size:11px}
  .tsub{font-size:10.5px;color:var(--tx3);margin-top:2px}
  footer{border-top:1px solid var(--line2);padding:30px 0;background:var(--ink);text-align:center;font-size:12.5px;color:var(--tx3)}
  footer a{color:var(--gold);text-decoration:none}
`}</style>

      <SiteHeader isLoggedIn={true} userType="company" unreadCount={unreadCount || 0} active={null} />
      <div className="fl-hero">
        <div className="aur"></div>
        <div className="wrap" style={{ position: "relative" }}>
          <Link href="/dashboard" className="back">← Back to dashboard</Link>
          <h1>My <span style={{ color: "var(--gold)" }}>Fleet</span></h1>
          <p className="sub">
            {vesselCount} vessel{vesselCount === 1 ? "" : "s"}
            {access.vesselLimit !== null ? ` · ${access.vesselLimit} included on your plan` : " · unlimited on Fleet plan"} — manage crew records for each one.
          </p>
        </div>
      </div>

      <section style={{ paddingTop: 0 }}>
        <div className="wrap">
          {fleetHealthScore !== null ? (
            <div className={`healthcard ${healthCls}`}>
              <div className="healthring">
                <span>{fleetHealthScore}%</span>
              </div>
              <div style={{ flex: 1, minWidth: 180 }}>
                <b>Fleet Health</b>
                <p>
                  {activeCrew.length} active crew ·{" "}
                  <Link href="/fleet?healthView=ready#health-list" className="healthlink hlgood">{fullyReadyCount} fully ready</Link>
                  {atRiskCount > 0 ? (
                    <> · <Link href="/fleet?healthView=atrisk#health-list" className="healthlink hlbad">{atRiskCount} at risk</Link></>
                  ) : null}
                </p>
              </div>
            </div>
          ) : null}
          {healthView && healthViewList.length > 0 ? (
            <div className="card" id="health-list">
              <h2>{healthView === "ready" ? "✅ Fully ready crew" : "⚠️ Crew at risk"}</h2>
              <div className="ttwrap">
                <table className="ctable">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Rank</th>
                      <th>Vessel</th>
                      <th>Readiness</th>
                    </tr>
                  </thead>
                  <tbody>
                    {healthViewList.map((c) => (
                      <tr key={c.id}>
                        <td>
                          <Link href={`/fleet/${c.vesselId}/${c.id}`} className="tname">{c.name}</Link>
                        </td>
                        <td>{c.rank}</td>
                        <td>{vesselNameMap[c.vesselId] || "Unknown vessel"}</td>
                        <td>
                          <span className={`rdybadge ${c.score >= 80 ? "rdy-high" : c.score >= 50 ? "rdy-mid" : "rdy-low"}`}>{c.score}%</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Link href="/fleet" className="filehint" style={{ display: "inline-block", marginTop: 12 }}>✕ Clear filter</Link>
            </div>
          ) : null}
          {totalAlerts > 0 ? (
            <div className="alertpanel">
              <span className="ai">⚠️</span>
              <div style={{ flex: 1, minWidth: 200 }}>
                <b>{totalAlerts} document{totalAlerts === 1 ? "" : "s"} expiring within 30 days across your fleet</b>
                <p>
                  {alertPassport > 0 ? alertPassport + " passport" + (alertPassport === 1 ? "" : "s") + " · " : ""}
                  {alertHealth > 0 ? alertHealth + " health report" + (alertHealth === 1 ? "" : "s") + " · " : ""}
                  {alertVisa > 0 ? alertVisa + " visa" + (alertVisa === 1 ? "" : "s") + " · " : ""}
                  {alertStcw > 0 ? alertStcw + " STCW endorsement" + (alertStcw === 1 ? "" : "s") : ""}
                </p>
              </div>
            </div>
          ) : null}
          {vesselList.length > 0 ? (
            <div className="costcard">
              <div className="costhead">
                <span>💰</span>
                <b>Fleet crew cost — monthly</b>
                <form method="get" style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
                  <select name="costVessel" defaultValue={costVessel} className="costsel">
                    <option value="">All vessels</option>
                    {vesselList.map((v) => (
                      <option key={v.id as string} value={v.id as string}>{v.name as string}</option>
                    ))}
                  </select>
                  <button type="submit" className="costgo">Show</button>
                </form>
              </div>
              {costCurrencies.length > 0 ? (
                <div className="costrows">
                  {costCurrencies.map((cur) => (
                    <div key={cur} className="costrow">
                      <span className="costcur">{cur}</span>
                      <span className="costval">{fmtMoney(costByCurrency[cur])}</span>
                      <span className="costproj">≈ {fmtMoney(costByCurrency[cur] * 12)} / 12 months</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="filehint">No salary data recorded {costVessel ? "for this vessel" : "yet"}.</p>
              )}
            </div>
          ) : null}
          {added === "1" ? <div className="banner ok">Vessel added.</div> : null}
          {deleted === "1" ? <div className="banner ok">Removed.</div> : null}
          {planned === "1" ? <div className="banner ok">Planned crew member added.</div> : null}
          {error === "missing" ? <div className="banner err">Please fill in the required fields.</div> : null}
          {error === "failed" ? <div className="banner err">Something went wrong — please try again.</div> : null}
          {error === "limit" ? (
            <div className="banner err">
              <span>You&apos;ve used your {access.vesselLimit} free vessel — upgrade to Fleet for unlimited vessels.</span>
              <Link href="/upgrade" className="btn btn-gold">Upgrade to Fleet →</Link>
            </div>
          ) : null}
          {!atLimit && access.vesselLimit !== null && vesselCount === 0 ? (
            <div className="banner info">
              You can add 1 vessel free and use every Fleet feature on it. Add a second vessel anytime with the Fleet plan.
            </div>
          ) : null}

          <div className="card">
            <h2>+ Add a vessel</h2>
            {atLimit ? (
              <div className="frow">
                <div>
                  <label htmlFor="name">Vessel name</label>
                  <input id="name" type="text" disabled placeholder="Upgrade to add another vessel" />
                </div>
                <div>
                  <label htmlFor="vesselType">Type</label>
                  <input id="vesselType" type="text" disabled />
                </div>
                <div>
                  <label htmlFor="flag">Flag</label>
                  <input id="flag" type="text" disabled />
                </div>
                <div>
                  <label htmlFor="dwt">DWT</label>
                  <input id="dwt" type="text" disabled />
                </div>
                <div>
                  <label htmlFor="imoNumber">IMO number</label>
                  <input id="imoNumber" type="text" disabled />
                </div>
                <Link href="/upgrade" className="btn-add on" style={{ textDecoration: "none", display: "inline-flex", alignItems: "center" }}>
                  Upgrade →
                </Link>
              </div>
            ) : (
              <form action={addVessel}>
                <div className="frow">
                  <div>
                    <label htmlFor="name">Vessel name</label>
                    <input id="name" name="name" type="text" required maxLength={100} placeholder="e.g. MV Ocean Star" />
                  </div>
                  <div>
                    <label htmlFor="vesselType">Type</label>
                    <input id="vesselType" name="vesselType" type="text" maxLength={60} placeholder="e.g. Bulk Carrier" />
                  </div>
                  <div>
                    <label htmlFor="flag">Flag</label>
                    <input id="flag" name="flag" type="text" maxLength={60} placeholder="e.g. Panama" />
                  </div>
                  <div>
                    <label htmlFor="dwt">DWT</label>
                    <input id="dwt" name="dwt" type="number" min="0" placeholder="e.g. 55000" />
                  </div>
                  <div>
                    <label htmlFor="imoNumber">IMO number</label>
                    <input id="imoNumber" name="imoNumber" type="text" maxLength={20} placeholder="Optional" />
                  </div>
                  <button type="submit" className="btn-add on">+ Add</button>
                </div>
              </form>
            )}
          </div>

          {vesselList.length === 0 ? (
            <div className="empty">
              No vessels yet — add your first one above to start tracking crew.
            </div>
          ) : (
            <div className="vgrid">
              {vesselList.map((v) => {
                const dwtLabel = fmtDwt(v.dwt as number | null);
                const metaParts = [
                  (v.vessel_type as string) || null,
                  (v.flag as string) ? "Flag: " + (v.flag as string) : null,
                  dwtLabel,
                ].filter(Boolean);
                return (
                  <div key={v.id as string} style={{ position: "relative" }}>
                    <Link href={`/fleet/${v.id}`} className="vcard">
                      <div className="vi">🚢</div>
                      <b>{v.name as string}</b>
                      <p>
                        {metaParts.length > 0 ? metaParts.join(" · ") : "Vessel details not set"}
                        <br />
                        {crewCountMap[v.id as string] || 0} active crew
                      </p>
                    </Link>
                    <div className="vdel">
                      <form action={deleteVessel}>
                        <input type="hidden" name="vesselId" value={v.id as string} />
                        <button type="submit">✕</button>
                      </form>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {vesselList.length > 0 ? (
            <>
              <div className="filterbar">
                <form method="get" style={{ display: "flex", gap: 10, flexWrap: "wrap", flex: 1 }}>
                  <select name="fVessel" defaultValue={fVessel} className="filtersel">
                    <option value="">All vessels</option>
                    {vesselList.map((v) => (
                      <option key={v.id as string} value={v.id as string}>{v.name as string}</option>
                    ))}
                  </select>
                  <select name="fRank" defaultValue={fRank} className="filtersel">
                    <option value="">All ranks</option>
                    {rankOptions.map((r) => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                  <button type="submit" className="btn btn-gold" style={{ padding: "9px 16px" }}>Filter</button>
                  {(fVessel || fRank) ? (
                    <Link href="/fleet" className="btn" style={{ color: "var(--tx3)", border: "1px solid var(--line2)" }}>Clear</Link>
                  ) : null}
                </form>
              </div>

              <div className="stitle">📜 Crew history — all vessels</div>
              <div className="card">
                {historyCrewFiltered.length === 0 ? (
                  <div className="empty">{historyCrew.length === 0 ? "No sign-offs recorded yet." : "No results match your filter."}</div>
                ) : (
                  <div className="ttwrap">
                    <table className="ctable">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Rank</th>
                          <th>Vessel</th>
                          <th>Signed Off</th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {historyCrewFiltered.map((c) => (
                          <tr key={c.id as string}>
                            <td>
                              <Link href={`/fleet/${c.vessel_id}/${c.id}`} className="tname">
                                {c.full_name as string}
                              </Link>
                              {c.notes ? <span className="tnoteflag" title="Has notes">📝</span> : null}
                            </td>
                            <td>{(c.rank as string) || "—"}</td>
                            <td>{vesselNameMap[c.vessel_id as string] || "Unknown vessel"}</td>
                            <td>{fmtDate(c.departure_date as string | null)}</td>
                            <td>
                              <form action={rehireCrew} className="rehireform">
                                <input type="hidden" name="crewId" value={c.id as string} />
                                <select name="targetVesselId" required defaultValue="" className="rehiresel">
                                  <option value="" disabled>Rehire to…</option>
                                  {vesselList.map((v) => (
                                    <option key={v.id as string} value={v.id as string}>{v.name as string}</option>
                                  ))}
                                </select>
                                <button type="submit" className="go">🔄</button>
                              </form>
                            </td>
                            <td>
                              <form action={moveToPlannedFromHistory} className="rehireform">
                                <input type="hidden" name="crewId" value={c.id as string} />
                                <select name="targetVesselId" required defaultValue="" className="rehiresel">
                                  <option value="" disabled>Plan for…</option>
                                  {vesselList.map((v) => (
                                    <option key={v.id as string} value={v.id as string}>{v.name as string}</option>
                                  ))}
                                </select>
                                <button type="submit" className="planbtn">📅</button>
                              </form>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <div className="stitle">📅 Planned sign-on — all vessels</div>
              <div className="card">
                <form action={addPlannedCrew} style={{ marginBottom: 16 }}>
                  <div className="frow">
                    <div>
                      <label htmlFor="pFullName">Full name</label>
                      <input id="pFullName" name="fullName" type="text" required maxLength={100} placeholder="e.g. Ahmed Yilmaz" />
                    </div>
                    <div>
                      <label htmlFor="pRank">Rank</label>
                      <input id="pRank" name="rank" type="text" maxLength={60} placeholder="e.g. 2nd Engineer" />
                    </div>
                    <div>
                      <label htmlFor="pVessel">Vessel</label>
                      <select id="pVessel" name="vesselId" required defaultValue="">
                        <option value="" disabled>Select vessel</option>
                        {vesselList.map((v) => (
                          <option key={v.id as string} value={v.id as string}>{v.name as string}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label htmlFor="pDate">Expected join</label>
                      <input id="pDate" name="expectedJoinDate" type="date" />
                    </div>
                    <div>
                      <label htmlFor="pCountry">Country</label>
                      <input id="pCountry" name="planningCountry" type="text" maxLength={60} placeholder="e.g. Philippines" />
                    </div>
                    <button type="submit" className="btn-add on">+ Plan</button>
                  </div>
                </form>

                {plannedCrewFiltered.length === 0 ? (
                  <div className="empty">{plannedCrew.length === 0 ? "No planned sign-ons yet — use the form above." : "No results match your filter."}</div>
                ) : (
                  <div className="ttwrap">
                    <table className="ctable">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Rank</th>
                          <th>Vessel</th>
                          <th>Expected Join</th>
                          <th>Status</th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {plannedCrewFiltered.map((c) => {
                          const statusRaw = ((c.planning_status as string) || "Tentative").toLowerCase();
                          const pillClass =
                            statusRaw.includes("confirm") ? "confirmed" : statusRaw.includes("doc") ? "docs" : "tentative";
                          const risk = getPlanningRisk(c);
                          return (
                            <tr key={c.id as string}>
                              <td>
                                <span className="tname" style={{ cursor: "default" }}>{c.full_name as string}</span>
                                {risk ? <div className="riskwarn">⚠️ {risk}</div> : null}
                              </td>
                              <td>{(c.rank as string) || "—"}</td>
                              <td>{vesselNameMap[c.vessel_id as string] || "Unknown vessel"}</td>
                              <td>
                                {fmtDate(c.expected_join_date as string | null)}
                                {c.planning_country ? <div className="tsub">{c.planning_country as string}</div> : null}
                              </td>
                              <td><span className={`ppill ${pillClass}`}>{(c.planning_status as string) || "Tentative"}</span></td>
                              <td>
                                <form action={activatePlannedCrew}>
                                  <input type="hidden" name="crewId" value={c.id as string} />
                                  <input type="hidden" name="vesselId" value={c.vessel_id as string} />
                                  <button type="submit" className="go">Sign on</button>
                                </form>
                              </td>
                              <td>
                                <form action={deletePlannedCrew}>
                                  <input type="hidden" name="crewId" value={c.id as string} />
                                  <button type="submit" className="tdel">✕</button>
                                </form>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </>
          ) : null}

          {auditRows && auditRows.length > 0 ? (
            <>
              <div className="stitle">🕐 Recent activity</div>
              <div className="card">
                <div className="alist">
                  {auditRows.map((a, idx) => (
                    <div key={idx} className="arow">
                      <span className="aic">{actionIcon(a.action as string)}</span>
                      <span className="atext">{a.detail as string}</span>
                      <span className="awhen">{fmtWhen(a.created_at as string)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : null}
        </div>
      </section>

      <footer>
        <div className="wrap">© 2026 ShipCrewFinder · <Link href="/dashboard">Dashboard</Link></div>
      </footer>
    </>
  );
}
