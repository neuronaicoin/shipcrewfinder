import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import type { ReactNode } from "react";
import { getPostBySlug, getAllSlugs, blogIndex, allPosts } from "@/app/data/blog";
import type { BlogPost } from "@/app/data/blog/types";
import { withBrand, jsonLd, SITE_URL } from "@/lib/seo";

// ---- Inline links -------------------------------------------------------
// Post text may contain markdown links "[text](/path)" and bare
// "shipcrewfinder.com/path" mentions. Render both as real <a> elements.
const INLINE_LINK_RE =
  /\[([^\]]+)\]\(((?:https?:\/\/|\/)[^)\s]+)\)|(?:https?:\/\/)?(?:www\.)?shipcrewfinder\.com(\/[A-Za-z0-9\-_/#?=&%.]*)?/g;

function linkProps(href: string) {
  const internal = href.startsWith("/") || /^https?:\/\/(www\.)?shipcrewfinder\.com/i.test(href);
  const path = internal ? href.replace(/^https?:\/\/(www\.)?shipcrewfinder\.com/i, "") || "/" : href;
  return { internal, path };
}

function renderInline(text: string): ReactNode {
  const out: ReactNode[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  INLINE_LINK_RE.lastIndex = 0;
  while ((m = INLINE_LINK_RE.exec(text)) !== null) {
    let label: string;
    let href: string;
    let matched = m[0];
    if (m[1]) {
      label = m[1];
      href = m[2];
    } else {
      // Bare domain mention: keep trailing sentence punctuation outside the link.
      const trail = matched.match(/[.,;:!?]+$/);
      if (trail) matched = matched.slice(0, -trail[0].length);
      label = matched;
      href = "/" + (m[3] || "").replace(/[.,;:!?]+$/, "").replace(/^\/+/, "");
    }
    if (m.index > last) out.push(text.slice(last, m.index));
    const { internal, path } = linkProps(href);
    const cls = "text-accent hover:text-accent-light underline underline-offset-2";
    out.push(
      internal ? (
        <Link key={m.index} href={path} className={cls}>{label}</Link>
      ) : (
        <a key={m.index} href={path} className={cls} target="_blank" rel="noopener noreferrer">{label}</a>
      )
    );
    last = m.index + matched.length;
    if (matched.length !== m[0].length) INLINE_LINK_RE.lastIndex = last;
  }
  if (last === 0) return text;
  if (last < text.length) out.push(text.slice(last));
  return out;
}

// Plain-text version for structured data (markdown links -> their label).
const plain = (t: string) => t.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");

// ---- Related guides -----------------------------------------------------
const normCat = (c: string) => c.toLowerCase().trim().replace(/s$/, "");
const STOP = new Set(["the", "and", "for", "a", "of", "to", "in", "on", "how", "what", "guide", "2026", "vs", "your", "with", "at", "is", "explained"]);
const words = (arr: string[]) =>
  new Set(
    arr
      .join(" ")
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter((w) => w.length > 2 && !STOP.has(w))
  );

function relatedPosts(post: BlogPost, n = 4) {
  const myCat = normCat(post.category);
  const myKw = new Set(post.keywords.map((k) => k.toLowerCase()));
  const myWords = words([...post.keywords, post.title]);
  const scored = allPosts
    .filter((p) => p.slug !== post.slug)
    .map((p) => {
      const sameCat = normCat(p.category) === myCat ? 1 : 0;
      const kwHits = p.keywords.filter((k) => myKw.has(k.toLowerCase())).length;
      let wordHits = 0;
      words([...p.keywords, p.title]).forEach((w) => {
        if (myWords.has(w)) wordHits++;
      });
      return { p, sameCat, overlap: kwHits * 3 + wordHits };
    })
    .sort(
      (a, b) =>
        b.sameCat - a.sameCat ||
        b.overlap - a.overlap ||
        new Date(b.p.date).getTime() - new Date(a.p.date).getTime()
    );
  const bySlug = new Map(blogIndex.map((e) => [e.slug, e]));
  return scored
    .slice(0, n)
    .map((x) => bySlug.get(x.p.slug))
    .filter((x): x is (typeof blogIndex)[number] => !!x);
}

const modifiedOf = (post: BlogPost) => {
  const m = (post as BlogPost & { dateModified?: string; updated?: string }).dateModified ||
    (post as BlogPost & { updated?: string }).updated;
  return m && !Number.isNaN(new Date(m).getTime()) ? m : post.date;
};

export function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) return { title: "Not Found — ShipCrewFinder" };

  const path = `/blog/${post.slug}`;
  const title = withBrand(post.title);
  return {
    title,
    description: post.description,
    keywords: post.keywords,
    authors: [{ name: "ShipCrewFinder", url: SITE_URL }],
    alternates: { canonical: path },
    openGraph: {
      title: post.title,
      description: post.description,
      url: path,
      type: "article",
      siteName: "ShipCrewFinder",
      locale: "en_US",
      publishedTime: post.date,
      modifiedTime: modifiedOf(post),
      section: post.category,
      tags: post.keywords,
      authors: [SITE_URL],
      images: [{ url: post.heroImage, alt: post.heroAlt }],
    },
    twitter: {
      card: "summary_large_image",
      site: "@shipcrewfinder",
      title: post.title,
      description: post.description,
      images: [post.heroImage],
    },
  };
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) notFound();

  const url = `https://shipcrewfinder.com/blog/${post.slug}`;

  const related = relatedPosts(post, 4);

  const fmtDate = (d: string) =>
    new Date(d).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

  const blogSchema = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "@id": `${url}#article`,
    headline: post.title,
    description: post.description,
    image: { "@type": "ImageObject", url: post.heroImage, caption: post.heroAlt },
    datePublished: post.date,
    dateModified: modifiedOf(post),
    inLanguage: "en",
    articleSection: post.category,
    author: {
      "@type": "Organization",
      "@id": `${SITE_URL}/#organization`,
      name: "ShipCrewFinder",
      url: SITE_URL,
    },
    publisher: {
      "@type": "Organization",
      "@id": `${SITE_URL}/#organization`,
      name: "ShipCrewFinder",
      url: SITE_URL,
      logo: { "@type": "ImageObject", url: `${SITE_URL}/apple-icon.png`, width: 180, height: 180 },
    },
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
    isPartOf: { "@type": "Blog", "@id": `${SITE_URL}/blog#blog`, name: "ShipCrewFinder Blog", url: `${SITE_URL}/blog` },
    keywords: post.keywords.join(", "),
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Blog", item: `${SITE_URL}/blog` },
      { "@type": "ListItem", position: 3, name: post.title, item: url },
    ],
  };

  const faqSchema =
    post.faqs.length > 0
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: post.faqs.map((f) => ({
            "@type": "Question",
            name: plain(f.question),
            acceptedAnswer: { "@type": "Answer", text: plain(f.answer) },
          })),
        }
      : null;

  return (
    <main className="min-h-screen bg-primary relative overflow-hidden">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: jsonLd(blogSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: jsonLd(breadcrumbSchema) }}
      />
      {faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: jsonLd(faqSchema) }}
        />
      )}

      <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary-light to-primary-dark" />
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `linear-gradient(#fbbf24 1px, transparent 1px), linear-gradient(90deg, #fbbf24 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <header className="relative border-b border-white/10 backdrop-blur-md bg-primary/85">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <svg viewBox="0 0 40 40" className="w-8 h-8" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2 14 Q10 6, 20 14 T38 14" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" opacity="0.3" />
              <path d="M2 20 Q10 12, 20 20 T38 20" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" opacity="0.6" />
              <path d="M2 26 Q10 18, 20 26 T38 26" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
            <span className="text-white font-display font-bold text-lg tracking-tight">
              Ship<span className="text-accent">Crew</span>Finder
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/blog" className="text-white/70 hover:text-white text-sm font-medium transition">Blog</Link>
            <Link href="/signup" className="px-4 py-2 bg-accent hover:bg-accent-dark text-primary font-bold text-sm rounded-lg transition shadow-lg shadow-accent/20">
              Sign Up Free
            </Link>
          </div>
        </div>
      </header>

      <article className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <Link
          href="/blog"
          className="inline-flex items-center gap-1.5 text-white/40 hover:text-white/60 text-sm transition mb-6"
        >
          ← Back to Blog
        </Link>

        <div className="flex items-center gap-2 mb-4">
          <span className="px-2.5 py-1 bg-accent/15 border border-accent/30 rounded-full text-accent text-[10px] font-bold uppercase tracking-wider">
            {post.category}
          </span>
          <span className="text-white/40 text-xs">{post.readingMinutes} min read</span>
          <span className="text-white/40 text-xs">·</span>
          <span className="text-white/40 text-xs">{fmtDate(post.date)}</span>
        </div>

        <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 tracking-tight leading-tight">
          {post.title}
        </h1>

        {/* Hero — patterned block (no image) */}
        <div className="relative w-full h-44 md:h-60 rounded-2xl mb-10 overflow-hidden bg-gradient-to-br from-primary-light via-primary to-primary-darker flex items-center justify-center">
          <div
            className="absolute inset-0 opacity-[0.12]"
            style={{
              backgroundImage: `linear-gradient(#fbbf24 1px, transparent 1px), linear-gradient(90deg, #fbbf24 1px, transparent 1px)`,
              backgroundSize: "32px 32px",
            }}
          />
          <div className="absolute -right-10 -top-10 w-48 h-48 bg-accent/10 rounded-full blur-3xl" />
          <div className="absolute -left-10 -bottom-10 w-48 h-48 bg-accent/10 rounded-full blur-3xl" />
          <svg className="relative w-20 h-20 text-accent/70" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 14 Q10 6, 20 14 T38 14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" opacity="0.4" />
            <path d="M2 20 Q10 12, 20 20 T38 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" opacity="0.7" />
            <path d="M2 26 Q10 18, 20 26 T38 26" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>

        <div className="space-y-5 mb-10">
          {post.intro.map((para, i) => (
            <p key={i} className="text-white/80 text-base md:text-lg leading-relaxed">
              {renderInline(para)}
            </p>
          ))}
        </div>

        <div className="space-y-10">
          {post.sections.map((section, i) => (
            <section key={i}>
              {section.heading && (
                <h2 className="font-display text-2xl md:text-3xl font-bold text-white mb-4 tracking-tight">
                  {section.heading}
                </h2>
              )}
              <div className="space-y-4">
                {section.paragraphs.map((para, j) => (
                  <p key={j} className="text-white/75 text-base leading-relaxed">
                    {renderInline(para)}
                  </p>
                ))}
              </div>
              {section.links && section.links.length > 0 && (
                <div className="mt-5 grid sm:grid-cols-2 gap-2.5">
                  {section.links.map((l, k) => (
                    <Link
                      key={k}
                      href={l.href}
                      className="block bg-primary-dark border border-white/10 hover:border-accent/50 rounded-lg px-4 py-2.5 text-sm text-accent hover:text-accent-light transition"
                    >
                      {l.text} →
                    </Link>
                  ))}
                </div>
              )}
            </section>
          ))}
        </div>

        {post.faqs.length > 0 && (
          <section className="mt-14">
            <h2 className="font-display text-2xl md:text-3xl font-bold text-white mb-6 tracking-tight">
              Frequently Asked Questions
            </h2>
            <div className="space-y-4">
              {post.faqs.map((faq, i) => (
                <div key={i} className="bg-primary-dark border border-white/10 rounded-2xl p-6">
                  <h3 className="font-display text-lg font-bold text-white mb-2">
                    {faq.question}
                  </h3>
                  <p className="text-white/70 text-sm leading-relaxed">{renderInline(faq.answer)}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {related.length > 0 && (
          <section className="mt-14">
            <h2 className="font-display text-2xl md:text-3xl font-bold text-white mb-6 tracking-tight">
              Related guides
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {related.map((r) => (
                <Link
                  key={r.slug}
                  href={`/blog/${r.slug}`}
                  className="group bg-primary-dark border border-white/10 hover:border-accent/40 rounded-2xl p-5 transition"
                >
                  <span className="px-2 py-0.5 bg-accent/15 border border-accent/30 rounded-full text-accent text-[10px] font-bold uppercase tracking-wider">
                    {r.category}
                  </span>
                  <h3 className="font-display text-base font-bold text-white mt-3 mb-1 leading-snug group-hover:text-accent transition">
                    {r.title}
                  </h3>
                  <p className="text-white/55 text-sm leading-relaxed line-clamp-2">
                    {r.excerpt}
                  </p>
                </Link>
              ))}
            </div>
          </section>
        )}

        <div className="mt-14 bg-primary-dark border border-accent/20 rounded-2xl p-8 text-center">
          <h2 className="font-display text-2xl font-bold text-white mb-3">
            Ready to find your next contract?
          </h2>
          <p className="text-white/60 text-sm mb-6 max-w-md mx-auto">
            Build a verified profile and get contacted directly by maritime companies worldwide. Free 7-day trial.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/signup/crew"
              className="px-6 py-3 bg-accent hover:bg-accent-dark text-primary font-bold rounded-lg transition shadow-lg shadow-accent/20"
            >
              Join as Crew
            </Link>
            <Link
              href="/signup/company"
              className="px-6 py-3 bg-white/10 hover:bg-white/15 text-white font-bold rounded-lg transition border border-white/10"
            >
              Hire Crew
            </Link>
          </div>
        </div>
      </article>
    </main>
  );
}
